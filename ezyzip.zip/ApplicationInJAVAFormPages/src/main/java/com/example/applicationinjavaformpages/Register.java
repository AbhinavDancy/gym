package com.example.applicationinjavaformpages;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Register extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String name = request.getParameter("user_name");
        String password = request.getParameter("user_password");
        String email = request.getParameter("user_email");

        out.println(name);
        out.println(email);
        out.println(password);
        out.println("welcome back");

        //connecting to db
        try {
            Class.forName("com.mysql.jdbc.driver");
                    Connection con= DriverManager.getConnection("jdbc:mysql:/localhost:3306/" +
                            "myFirstDB","root","Abhi1@gmail");
                    String query="insert into register(name ,password,email)values(?,?,?)";
            PreparedStatement ps=con.prepareStatement(query);
            ps.setString(1,name);
            ps.setString(2,password);
            ps.setString(3,email);
            ps.executeUpdate();
            con.close();
            out.println("its done..........");

        }catch (Exception e)
        {
            out.println(e.getMessage());
            out.println(e);

            out.println("<h1> ERROR </h1>");
        }


        //connecting via jpa
//        EntityManagerFactory emf = Persistence.createEntityManagerFactory("default");
//        EntityManager em = emf.createEntityManager();
//
//        em.getTransaction().begin();
//        Login l1 = new Login();
//        l1.setName(name);
//
//        out.println(" againnnn.......");
//        l1.setEmail(email);
//        l1.setPassword(password);
//        em.persist(l1);
//        out.println("welcome  againnnn.......");
//        em.getTransaction().commit();
//
//        emf.close();
//        em.close();
//        out.println("welcome back againnnn.......");
    }
}